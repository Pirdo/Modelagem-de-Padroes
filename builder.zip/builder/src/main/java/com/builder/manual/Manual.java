package com.builder.manual;

public class Manual {
    
}
